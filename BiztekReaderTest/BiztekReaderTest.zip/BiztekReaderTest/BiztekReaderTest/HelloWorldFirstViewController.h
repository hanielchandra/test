//
//  HelloWorldFirstViewController.h
//  BiztekReaderTest
//
//  Created by Bernaridho Hutabarat on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloWorldFirstViewController : UIViewController

@end
